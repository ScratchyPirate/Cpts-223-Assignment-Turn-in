#include "TwitterData.hpp"

string TwitterData::getUserName() const
{
	return *(this->mpUserName);
}

string TwitterData::getActualName() const
{
	return *(this->mpActualName);
}

string TwitterData::getEmail() const
{
	return *(this->mpEmail);
}

string TwitterData::getCategory() const
{
	return *(this->mpCategory);
}

int TwitterData::getNumTweets() const
{
	return *(this->mpNumTweets);
}

void TwitterData::setUserName(const string& newUserName)
{
	delete mpUserName;
	mpUserName = new string(newUserName);
}

void TwitterData::setActualName(const string& newActualName)
{
	delete mpActualName;
	mpActualName = new string(newActualName);
}

void TwitterData::setEmail(const string& newEmail)
{
	delete mpEmail;
	mpEmail = new string(newEmail);
}

void TwitterData::setCategory(const string& newCategory)
{
	delete mpCategory;
	mpCategory = new string(newCategory);
}

void TwitterData::setNumTweets(const int& newNumTweets)
{
	delete mpNumTweets;
	mpNumTweets = new int(newNumTweets);
}