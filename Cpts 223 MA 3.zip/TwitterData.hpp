#ifndef TWITTER_DATA_H
#define TWITTER_DATA_H

#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <iostream>
#include <cstring>	
#include <vector>
#include <queue>
#include <initializer_list>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <Windows.h>
#include <conio.h>

class TwitterData
{
public:
	// Are the Big Five necessary?
	// How will this data work with the std::map?

	string getUserName() const; // we do want to return a copy of the string, not the pointer
	string getActualName() const; // we do want to return a copy of the string, not the pointer
	string getEmail() const; // we do want to return a copy of the string, not the pointer
	string getCategory() const; // we do want to return a copy of the string, not the pointer
	int getNumTweets() const; // we do want to return a copy of the integer, not the pointer

	void setUserName(const string &newUserName); // you need to implement
	void setActualName(const string& newActualName); // you need to implement
	void setEmail(const string &newEmail); // you need to implement
	void setCategory(const string &newCategory); // you need to implement
	void setNumTweets(const int &newNumTweets); // you need to implement

	TwitterData() {

		mpUserName = new std::string();
		mpActualName = new std::string();
		mpEmail = new std::string();
		mpCategory = new std::string();
		mpNumTweets = new int();

	}


private:
	string *mpUserName, *mpActualName, 
		*mpEmail, *mpCategory;
	int *mpNumTweets;	
};

#endif

