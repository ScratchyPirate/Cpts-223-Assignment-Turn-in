/*
MA 3 Questions

What piece of data read from the file did you use for the key and why?
	I made the key for the pairs the email of the users. It made it a bit harder to 
	find each member to remove since I had to look at the other side of each pair to
	determine whether to delete it or not. However, I believe this is more accurate to
	twitter since I believe each email can only be tied to 1 account so it makes sense 
	that if the key can't repeat, that the email would be more logical. Their @username
	would also work, but it didn't look like the .csv file held those so  I didn't use
	username. However, that would make more sense since there can only be 1 @username for
	each user name. So there can't be 2 @john_sbur in the system.

Assuming that the map is using a red-black tree, what is the worst-case Big-O for inserting key-value pairs based on a key?
	O(log(base2)(N)). For retrieving data from the tree, the furthest down a path you 
	should have to go is log(base2)(N) where N is the total number of black nodes in the
	tree. The rotations and color changing functions are predetermined in how long they
	will take to complete based on the properties of the tree and the subtree the insertion
	occured on, but not based on how many nodes are in the tree, so the operation is based on 
	its black height so O(log(base2)(N))

Assuming that the map is using a red-black tree, what is the worst-case Big-O for retrieving data based on a key?
	O(log(base2)(N)). For retrieving data from the tree, the furthest down a path you 
	should have to go is log(base2)(N) where N is the total number of black nodes in the
	tree. This is because the black height of the tree is also log(base2)(N). Every path from 
	a node in the tree to any of its descendant NULL node has the same number of black 
	nodes so the tree's black nodes are always balanced and there are equal amounts on
	each side of each subtree. Therefore, the black height of the tree is always 
	log(base2)(N) and at most, the data retrieving searches log(base2)(N) nodes. 
	Therefore, retrieving data is at worst case a O(log(base2)(N)) operation.

Assuming that the map is using a red-black tree, what is the worst-case Big-O for deleting key-value pairs based on a key?
	O(log(base2)(N)). For retrieving data from the tree, the furthest down a path you
	should have to go is log(base2)(N) where N is the total number of black nodes in the
	tree. The rotations and color changing functions that occur after the deletion are
	predetermined based on the properties of the subtree the node was on, but not based
	on how many nodes there are in the tree. So with the deletion and the rotations and
	color changes that might occur after, the delete function for key values is 
	O(log(base2)(N)).

Assuming that the map is using a red-black tree, what is the worst-case Big-O for iterating through the entire map?
	O(n). The worst case for iteration in any type of BST is to look at every single 
	node in the tree. This means you look at n nodes without repeats,where n is the 
	total amount of nodes in the tree, so the worst case is just O(n).
	
Based on the specific algorithm that you used to find and remove a key-value pair based on a value, what is the worst-case Big-O?
	The specific algorithm I made for removing a key-value pair's worst case I believe 
	is O(n) where n is the number of nodes in the tree. The worst case would be if the
	iterator had to look at each node and find the node to delete at the very end, which
	means it searches through n nodes. The deletion that happens afterwards is the same
	as the normal deletion which is O(log(base2)(N)), but O(N) is a larger time complexity
	than O(log(base2)(N)), so the overall algorithm is O(N);

Based on your conclusions of the tasks that were performed in this assignment, when and why should we use a map?
	I believe that we want to use a map when we want to any of these 3 things: make sure that similar
	data isn't inserted, have easier deletions, and want to use a red-black tree for faster
	traversal. The pairs that you have to insert into the map make it easier for the program
	to check to see if the key is matching another key rather than all the data in each
	node. It's also easier to delete data since if you know the key of the value you want to
	delete, you only need to enter that instead of looking through the data for a specific data
	value and deleting based on that. Finally, using a red-black tree means that traversing 
	through the tree, while not as fast as an AVL tree, is still quite fast while also making
	insertions and deletions not take as long as an AVL tree. I think you would want a Red-Black
	tree when you are going to be making a lot of insertions and deletions into it since the
	overall time would be cut compared to and AVL tree.

Assuming that the �MostViewedCategory� data in the file represents the kind of Tweets that a particular user views frequently. 
Is a map an ideal data structure to use to retrieve this information, especially if we want to use the info for advertising? 
If not, what data structure would you use instead?
	I believe that this data structure works for that purpose, but I think that there is a more
	efficient alternative. Since we are mainly retrieving data or updating based on what this
	user searches for, I think that an AVL tree would be better suited for this. My reasoning is 
	that Black and Red trees are great for when you are doing a lot of insertions and deletions
	since there are less rotations and the actual tree isn't as balanced as an AVL, but searching 
	for data can still be fast since the black height of the tree is still balanced. However, by 
	using an AVL tree, though the insertions will be slower as well as the deletions, we aren't 
	aiming to do that. We only want to update or retrieve data from a particular user, so an AVL
	tree would be better. The entire tree is balanced, so to get to each user in the worst case
	scenario is O(log(base2)(N)) where N is the number of users. Though the big-O is the same
	for Red-Black trees, the N is based on the black height, so the entire tree might not be
	as balanced as an AVL tree in its worst case and therefore take more time to traverse and 
	retrieve data. Because of this, I believe that an AVL tree is more well suited for the
	retrieving of data. 
	(If this was for the entire Twitter Algorithm, I think that Red-Black would be more well suited 
	since with every new user comes a new insertion which takes
	AVL trees much longer to do.)

*/

#include <map>
#include "TwitterData.hpp"

int main(int argc, char* argv[])
{
	// we need a map to store our key-value pairs
	// std::map<keyType, ValueType>; What should the key be? What about the value?

	//String Setter Debug
	/*TwitterData temp;
	temp.setActualName("John");
	std::cout << temp.getActualName() << std::endl;
	temp.setActualName("Bob");
	std::cout << temp.getActualName();*/
	
	//Int Setter Debug
	/*TwitterData temp2;
	temp2.setNumTweets(3);
	std::cout << temp2.getNumTweets() << std::endl;*/


	//Declare general variables
	map<string, TwitterData> twitter_accounts;
	string::size_type sz;
	TwitterData* temp = new TwitterData();
	string temp_s_1;
	string temp_s_2;
	bool iterating = true;
	int c = 0;

	//Declare and open file
	fstream twitter_file;
	twitter_file.open("TwitterAccounts.csv", ios::in);
	
	

	//Get junk first line
	getline(twitter_file, temp_s_2, '\n');

	//"read and parse all the data in TwitterAccounts.csv" Requirement
	while (twitter_file.good()) {

		delete temp;
		temp = new TwitterData();

		getline(twitter_file, temp_s_1, ',');
		if (temp_s_1 != "") {

			//Username
			temp->setUserName(temp_s_1);
			getline(twitter_file, temp_s_1, '"');

			//Actual Name
			getline(twitter_file, temp_s_1, ',');
			getline(twitter_file, temp_s_2, ',');
			temp_s_1 = temp_s_1 + ',' + temp_s_2;
			temp->setActualName(temp_s_1);

			//Email
			getline(twitter_file, temp_s_1, ',');
			temp->setEmail(temp_s_1);

			//Num Tweets
			getline(twitter_file, temp_s_1, ',');
			temp->setNumTweets(stoi(temp_s_1, &sz));

			//Category
			getline(twitter_file, temp_s_1, '\n');
			temp_s_1.pop_back();
			temp->setCategory(temp_s_1);
			//getline(twitter_file, temp_s_1, '\n');


			//"insert the data into the std::map" Requirement
			twitter_accounts.insert(pair<string, TwitterData>(temp->getEmail(), *temp));

		}	


	}

	//Close input file
	twitter_file.close();



	//3 prints with deletions

	//First print (No items removed)
	cout << "Printing list. No deletions made." << endl;
	for (map<string, TwitterData>::iterator i = twitter_accounts.begin(); i != twitter_accounts.end(); i++) {
		cout << "<" << (*i).first << "|,|" << (*i).second.getUserName() << ":" << (*i).second.getActualName() << ":" << (*i).second.getEmail() << ":" << (*i).second.getNumTweets() << ":" << (*i).second.getCategory() << ">" << endl;
	}
	cout << endl;
	cout << "Press any button to continue: " << endl;
	_getch();


	//"remove the key-value pair matching �savage1�" Requirement
	cout << "Deleting 'savage1'" << endl;
	for (map<string, TwitterData>::iterator i = twitter_accounts.begin(); c < twitter_accounts.size() && iterating;) {

		if ((*i).second.getUserName() == "savage1") {

			twitter_accounts.erase(i);
			iterating = false;

		}
		else {

			i++;

		}
		
		c++;

	}
	c = 0;
	iterating = true;
	//2nd print after deletion
	for (map<string, TwitterData>::iterator i = twitter_accounts.begin(); i != twitter_accounts.end(); i++) {
		cout << "<" << (*i).first << "|,|" << (*i).second.getUserName() << ":" << (*i).second.getActualName() << ":" << (*i).second.getEmail() << ":" << (*i).second.getNumTweets() << ":" << (*i).second.getCategory() << ">" << endl;
	}
	cout << endl;
	cout << "Press any button to continue: " << endl;
	_getch();


	//"remove the key-value pair matching �Smith,Rick�" Requirement
	cout << "Deleting 'Smith,Rick'" << endl;
	for (map<string, TwitterData>::iterator i = twitter_accounts.begin(); c < twitter_accounts.size() && iterating;) {

		if ((*i).second.getActualName() == "Smith,Rick") {

			twitter_accounts.erase(i);
			iterating = false;

		}
		else {

			i++;

		}

		c++;

	}
	c = 0;
	iterating = true;
	//3rd print after final deletion
	for (map<string, TwitterData>::iterator i = twitter_accounts.begin(); i != twitter_accounts.end(); i++) {
		cout << "<" << (*i).first << "|,|" << (*i).second.getUserName() << ":" << (*i).second.getActualName() << ":" << (*i).second.getEmail() << ":" << (*i).second.getNumTweets() << ":" << (*i).second.getCategory() << ">" << endl;
	}
	cout << endl;
	cout << "Press any button to continue: " << endl;
	_getch();



	return 0;
}