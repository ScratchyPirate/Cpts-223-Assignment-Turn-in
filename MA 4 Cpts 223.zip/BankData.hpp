#ifndef BANK_DATA_H
#define BANK_DATA_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

class BankData
{
public:

	//Task 9
	//Default constructor
	BankData() {

		mpAcctNum = new int();
		mpSavingsAmount = new double();
		mpCheckingAmount = new double();

	}

	//Destructor
	~BankData() {

		//delete mpAcctNum;
		//delete mpCheckingAmount;
		//delete mpSavingsAmount;

	}

	//Copy constructor
	explicit BankData(BankData* new_data) {

		this->setAcctNum(new_data->getAcctNum());
		this->setCheckingAmount(new_data->getCheckingAmount());
		this->setSavingsAmount(new_data->getSavingsAmount());

	}

	// Are the Big Five necessary? (not necessarily, but it does make things easier)
	// How will this data work with the std::map?

	int getAcctNum() const; // we do want to return a copy of the int, not the pointer
	double getSavingsAmount() const; // we do want to return a copy of the double, not the pointer
	double getCheckingAmount() const; // we do want to return a copy of the double, not the pointer

	void setAcctNum(const int& newAcctNum); // you need to implement
	void setSavingsAmount(const double& newSavingsAmount); // you need to implement
	void setCheckingAmount(const double& newCheckingAmount); // you need to implement

private:
	int* mpAcctNum;
	double* mpSavingsAmount, * mpCheckingAmount;
};

#endif

