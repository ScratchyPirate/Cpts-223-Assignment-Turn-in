#include "BankData.hpp"

int BankData::getAcctNum() const
{
	return *(this->mpAcctNum);
}

double BankData::getSavingsAmount() const
{
	return *(this->mpSavingsAmount);
}

double BankData::getCheckingAmount() const
{
	return *(this->mpCheckingAmount);
}

//Task 1
void BankData::setAcctNum(const int& newAcctNum)
{
	*mpAcctNum = newAcctNum;
}

void BankData::setSavingsAmount(const double& newSavingsAmount)
{
	*mpSavingsAmount = newSavingsAmount;
}

void BankData::setCheckingAmount(const double& newCheckingAmount)
{
	*mpCheckingAmount = newCheckingAmount;
}