
#include <unordered_map>
#include "BankData.hpp"
/*
	File Creator: Andrew Ofallon
	Project Editor: John Sbur
	Assignment: MA 4
	Class: Cpts 223
	Last Updated: 11/9/20

*/
/*
	MA 4 Questions:

	Assuming that the underlying hash table created cannot be resized, and that the hash function is poor, what is the worst-case Big-O for inserting key-value pairs based on a key? List any other assumptions that you make.
		It looks like this unorganized_map resolves collisions by chaining since it can support multiple entries in a bucket. The worst case would be if all the elements were in 1 key and this insertion also had the same key.
		In that case, the insertion time would take O(n) time where n is the number of elements in the map. The reason is that to insert the element, the algorithm would have to go through each element in the linked list, which
		is also each element in the map. It would then insert it at the end of the linked list after looking at n elements so this operation is worst-case O(n).

	Let�s say that the underlying hash table uses linear probing, what is the worst-case Big-O for retrieving data based on a key? List any assumptions that you make.
		Worst case for retriecing data based on a key is O(n). If all elements in the hash map are mapped to the same index, but set by an offset and you need to find the one that's the furthest away from that offset, you would need
		to go through each element so the worst case is O(n).

	Let�s say the underlying hash table uses chaining, what is the worst-case Big-O for deleting key-value pairs based on a key? List any assumptions that you make.
		The worst case is still if all the elements are mapped to the same index and the element you need to delete is at the end of the linked list chain. In this case, the operation would be an O(n) operation so the worst case
		would be O(n).

	What is the worst-case Big-O for iterating through the entire unordered map? List any assumptions that you make.
		To iterate through the entire unordered map is to 1: look at each bucket and to 2: look at each element in each bucket. You can still iterate through a bucket even if it's empty. So you look at each element in the bucket, 
		we'll say that there are n elements. We also look at each bucket, we'll say there are h buckets. h is constant for any iteration through an unordered map so we'll consider it as such. Therefore, the iteration operator is
		an O(n + h) operation or O(n) at worst-case.

	Based on your conclusions of the tasks that were performed in this assignment, when and why should we use an unordered map?
		I believe we use maps when we need to store data, but not just different key values. We use maps to store pairs of data, which allows use to store more complex data rather than just keys. In this assignment, we were able to
		store not only keys, but also complex objects like the BankData class alongside the key. We use them because it gives us this ability. Since insert, delete, and find on average are O(1), we can use them when we want these
		operations to be fast, but we also need a lot of space to support the map as having a load factor become too high lowers the efficiency of the operations. So when we have a lot of memory and need data storing and editing to
		be fast, we use unordered maps.

	Is an std::unordered_map a robust choice for storing, removing, and searching bank accounts? Explain.
		I think it's a very robust choice for storing, removing, and searching bank accounts. It's very efficient when the load factor is low. Search, insert, and delete functions don't take a long time to complete on average as long
		as the load factor is kept low. If the company or organization can keep it low, then it's a great tool for them. It definitely isn't the most efficient in terms of memory since in order to keep the load factor low, you have to
		keep rehashing and taking up more and more memory. If they can't keep up with it, then maybe a BST of sort would be better. After all, to store millions of accounts' data would cost a lot of money to maintain. For a small bank or
		a data set that's small in size, it's more reasonable to use. However, for a larger bank or organization, I would say no.




*/
int main(int argc, char* argv[])
{

	//Tasks
	//-1 Setters (See .cpp file for BankData)
	//-2 Data from files
	//-3 Insertion
	//-4 Printing data from each mapped bucket (All were printed)
	//-5 Print out the number of elements in the map (twice)
	//-6 Print out the max number of elements that can be stored in the map
	//-7 Iterate through the map and print key value pairs (twice)
	//-8 Remove key pair matching 11111111
	//-9 Other (Implemented More stuff in BankData.hpp) (I'm not sure what you wanted to create a solution for if it says 'other functions' with no problems given)


	//Key is Account Number, Valuetype is BankData corresponding to Account Number
	unordered_map<int, BankData> Bank_Records;
	
	//Set up files
	fstream bank_file;
	bank_file.open("BankAccounts.csv", ios::in);

	//Declare general variables
	string::size_type sz;
	BankData* temp = new BankData();
	string temp_s_1;
	string temp_s_2;
	string temp_s_3;
	int temp_n_1;
	double temp_n_2;
	double temp_n_3;



	//Gets rid of the first string
	if (bank_file.good()) {
		getline(bank_file, temp_s_1, '\n');
	}
	//Insertions from the file (Tasks 2 and 3)
	while (bank_file.good()) {

		getline(bank_file, temp_s_1, ',');
		getline(bank_file, temp_s_2, ',');
		getline(bank_file, temp_s_3, '\n');

		if (temp_s_1 != "" && (temp_s_2 != "" && temp_s_3 != "")) {

			temp_n_1 = stoi(temp_s_1, &sz);
			temp_n_2 = stod(temp_s_2, &sz);
			temp_n_3 = stod(temp_s_3, &sz);
			temp->setAcctNum(temp_n_1);
			temp->setSavingsAmount(temp_n_2);
			temp->setCheckingAmount(temp_n_3);

			cout << temp_s_1 << ": " << temp_s_2 << ":" << temp_s_3 << endl;

			Bank_Records.insert({ temp->getAcctNum(),*temp });

		}
		

	}
	cout << endl << endl;


	//Print out the max number of buckets and max number of elements (Task 6)
	cout << "There can be " << Bank_Records.max_bucket_count() << " buckets." << endl;
	cout << "There can be " << Bank_Records.max_size() << " elements" << endl;
	
	//Print different data in each bucket
	//First print the number of buckets and elements (Tasks 5 and 7 part 1) (Task 4)
	cout << "There are " << Bank_Records.bucket_count() << " buckets." << endl;
	cout << "There are " << Bank_Records.size() << " elements" << endl << endl;
	//Iterate through each bucket.	
	for (int i = 0; i < Bank_Records.bucket_count(); i++) {

		cout << "Bucket: " << i << endl;

		//Print data in each bucket
		for (unordered_map<int, BankData>::iterator i_bucket = Bank_Records.begin(i); i_bucket != Bank_Records.end(i); i_bucket++){

			cout << " " << i_bucket->first << ": <Account Number:" << i_bucket->second.getAcctNum() << "| Savings:" << i_bucket->second.getSavingsAmount() << "| Checkings:" << i_bucket->second.getCheckingAmount() << ">" << endl;

		}

		cout << endl;

	}
	system("pause");
	system("cls");

	//Remove key pair with 11111111 (Task 8)
	Bank_Records.erase(Bank_Records.find(11111111));
	cout << "Erased elements corresponding with key 11111111" << endl;
	system("pause");
	system("cls");


	//Print different data in each bucket
	//First print the number of buckets and elements (Tasks 5 and 7 part 2) (Task 4 again)
	cout << "There are " << Bank_Records.bucket_count() << " buckets." << endl;
	cout << "There are " << Bank_Records.size() << " elements" << endl << endl;
	//Iterate through each bucket.	
	for (int i = 0; i < Bank_Records.bucket_count(); i++) {

		cout << "Bucket: " << i << endl;

		//Print data in each bucket
		for (unordered_map<int, BankData>::iterator i_bucket = Bank_Records.begin(i); i_bucket != Bank_Records.end(i); i_bucket++) {

			cout << " " << i_bucket->first << ": <Account Number:" << i_bucket->second.getAcctNum() << "| Savings:" << i_bucket->second.getSavingsAmount() << "| Checkings:" << i_bucket->second.getCheckingAmount() << ">" << endl;

		}

		cout << endl;

	}
	system("pause");
	system("cls");

	bank_file.close();

	return 0;
}