
/*

	File Creator: John Sbur
	Assignment: PA 3
	Class: Cpts 223
	Created: 10/4/20
	Last Updated: 10/9/20

	Purpose: To further define the CancerData member functions.

*/

#include "CancerData.h"

//Setters and getters
void CancerData::set_country(string new_country) {

	country = new_country;

}
void CancerData::set_rate(double new_rate) {

	cancer_rate = new_rate;
}
string CancerData::get_country() {

	return country;

}
float CancerData::get_rate() {

	return cancer_rate;

}
