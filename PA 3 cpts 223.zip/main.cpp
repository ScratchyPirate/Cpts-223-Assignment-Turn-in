
/*

	File Creator: John Sbur
	Assignment: PA 3
	Class: Cpts 223
	Created: 10/4/20
	Last Updated: 10/9/20

	Purpose: To include necessary tasks for fufilling the requirements of PA 3.
	Main.cpp does the following:
	-Read cancer data from 3 text files, 1 being the cancer rate for men, 1 for women, and 1 for both sexes
	-List on 3 separate lines the 1st ranked country for the global cancer rates for both sexes, men, and women.
	-List on 3 separate lines the 50th ranked country for the global cancer rates for both sexes, men, and women. 

*/

/*
PA 3 Questions:

What is the worst-case Big-O of the insert () algorithm for the AVL tree? Explain.
	A: O(log(base2)(N)). If there are N elements in the tree and because the tree is always balanced, the furthest it has
	to go to insert is based on the height of the root. If the height is 3, then at worst, the tree has 7 nodes, but only
	has to search through 3 which is roughly log(base2)(7). (Equal to 2.8ish). If the height is 4, then there are 15 nodes,
	but the insert function only needs to look at 4 which is roughly log(base2)(15). There is a constant multiplier and a
	constant addative, but the important part is that the insertion is O(log(base2)(n)). The actual rotations within the 
	balancing are a predetermined amount of actions based off of the properties of the subtree so those don't affect
	the notation.

What is the worst-case Big-O of the printInOrder() algorithm for the AVL tree? Explain. 
	A: O(n). Each node in the tree is printed once in inorderprint and if there are n nodes, then that means that n nodes
	are printed. 

What is the worst-case Big-O of the findMax () algorithm for the AVL tree? Explain.
	O(log(base2)(N)). Much for the same reason as insert. The furthest the function goes to the right is based on how many 
	levels are in the tree since the highest rate stored based on my storing method will always be the furthest right node.
	If the height is 3, then at worst, the tree has 7 nodes, but only has to go through 3, the root, the next right and the
	right after that, which is roughly log(base2)(7). (Equal to 2.8ish).

*/
#include "AVLTree.h"

int main() {

	//CancerData Copy assignment test
	/*
	CancerData* temp1 = new CancerData("Sweden", .1);
	CancerData* temp2 = new CancerData("Ireland", .2);

	cout << temp1->get_country() << temp1->get_rate() << endl;
	temp1 = temp2;
	cout << temp1->get_country() << temp1->get_rate();
	*/
	
	//Create trees. Set labels
	AVLTree<AVLNode<CancerData>>* cancer_tree_both = new AVLTree<AVLNode<CancerData>>();
	AVLTree<AVLNode<CancerData>>* cancer_tree_men = new AVLTree<AVLNode<CancerData>>();
	AVLTree<AVLNode<CancerData>>* cancer_tree_women = new AVLTree<AVLNode<CancerData>>();
	cancer_tree_both->set_label("Both");
	cancer_tree_men->set_label("Men");
	cancer_tree_women->set_label("Women");

	//Create files
	fstream both;
	fstream men;
	fstream women;

	//Open files for reading
	both.open("bothcancerdata2018.csv", ios::in);
	men.open("mencancerdata2018.csv", ios::in);
	women.open("womencancerdata2018.csv", ios::in);

	//General Variables
	string::size_type sz;
	CancerData temp;
	AVLNode<CancerData>* temp_node;
	CancerData* temp2;
	string temp_s_1;
	string temp_s_2;

	//Insertions for both
	while (both.good()) {

		getline(both, temp_s_1, ',');
		getline(both, temp_s_2, '\n');
		temp.set_country(temp_s_1);
		temp.set_rate(stof(temp_s_2, &sz));

		//cout << "Country loaded..." << endl;
		//cout << temp_s_1 << ": " << temp_s_2 << endl;

		cancer_tree_both->insert(temp);

	}
	cout << endl << endl;

	//Insertions for men
	while (men.good()) {

		getline(men, temp_s_1, ',');
		getline(men, temp_s_2, '\n');
		temp.set_country(temp_s_1);
		temp.set_rate(stof(temp_s_2, &sz));

		//cout << "Country loaded..." << endl;
		//cout << temp_s_1 << ": " << temp_s_2 << endl;

		cancer_tree_men->insert(temp);

	}

	//Insertions for women
	while (women.good()) {

		getline(women, temp_s_1, ',');
		getline(women, temp_s_2, '\n');
		temp.set_country(temp_s_1);
		temp.set_rate(stof(temp_s_2, &sz));

		//cout << "Country loaded..." << endl;
		//cout << temp_s_1 << ": " << temp_s_2 << endl;

		cancer_tree_women->insert(temp);

	}
	cout << endl << endl;

	//Close files
	both.close();
	men.close();
	women.close();


	//Print data from both tree

	cout << "Cancer rate for both genders in different countries" << endl << endl;

		//Print from 1 - 50 rates
	cancer_tree_both->print_in_order_reverse();
	cout << endl;

		//Print min
	temp_node = new AVLNode<CancerData>(cancer_tree_both->find_min_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_both->get_label() << ":" << 50 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

		//Print max
	temp_node = new AVLNode<CancerData>(cancer_tree_both->find_max_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_both->get_label() << ":" << 1 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

	cout << "Press any button to continue" << endl;
	_getch();
	system("CLS");


	//Print data from both tree

	cout << "Cancer rate for men in different countries" << endl << endl;

		//Print from 1 - 50 rates
	cancer_tree_men->print_in_order_reverse();
	cout << endl;

	//Print min
	temp_node = new AVLNode<CancerData>(cancer_tree_men->find_min_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_men->get_label() << ":" << 50 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

	//Print max
	temp_node = new AVLNode<CancerData>(cancer_tree_men->find_max_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_men->get_label() << ":" << 1 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

	cout << "Press any button to continue" << endl;
	_getch();
	system("CLS");



	//Print data from both tree

	cout << "Cancer rate for women in different countries" << endl << endl;

		//Print from 1 - 50 rates
	cancer_tree_women->print_in_order_reverse();
	cout << endl;

	//Print min
	temp_node = new AVLNode<CancerData>(cancer_tree_women->find_min_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_women->get_label() << ":" << 50 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

	//Print max
	temp_node = new AVLNode<CancerData>(cancer_tree_women->find_max_node());
	temp2 = new CancerData(temp_node->get_data());
	cout << "<" << cancer_tree_women->get_label() << ":" << 1 << "." << temp2->get_country() << "." << temp2->get_rate() << ">" << endl;

	cout << "Press any button to continue" << endl;
	_getch();
	system("CLS");


	//Debug remove
	/*cout << "Debug remove()" << endl;
	cancer_tree_both->remove(*temp2);
	temp2->set_country("Italy");
	temp2->set_rate(290.6);
	cancer_tree_both->remove(*temp2);
	cout << "Success" << endl;*/

	//Debug clear
	/*cout << "Debug clear()" << endl;
	cancer_tree_both->clear();
	cout << "Success" << endl;*/

	return 0;

}