#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 3
	Class: Cpts 223
	Created: 10/4/20
	Last Updated: 10/9/20

	Purpose: To define the CancerData class and declare it's member functions.

*/

#include "declarations.h"

class CancerData {


private:

	string country;
	float cancer_rate;

public:

	//Default contructor
	CancerData(){

		country = "";
		cancer_rate = 0.0;

	}

	//Explicit copy constructor
	explicit CancerData(string new_country, float new_rate) {

		country = new_country;
		cancer_rate = new_rate;

	}

	//Copy constructor from CancerData
	explicit CancerData(CancerData* new_data) {

		this->set_country(new_data->get_country());
		this->set_rate(new_data->get_rate());

	}

	//Destructor. (Without addresses to delete I'm not sure what to delete. You can't delete the addresses of the
	// variables. "delete[] &country" doesn't work so I'm leaving this blank unless I come back to it and add
	// other members with addresses)
	~CancerData() {


	}

	//Copy Assignment
	CancerData& operator=(CancerData& source) {

		this->cancer_rate = source.cancer_rate;
		this->country = source.country;

		return *this;

	}

	//Setters and getters
	void set_country(string new_country);
	void set_rate(double new_rate);
	void set_height(int new_height);
	string get_country();
	float get_rate();
	int get_height();



};