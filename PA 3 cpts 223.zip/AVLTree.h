#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 3
	Class: Cpts 223
	Created: 10/4/20
	Last Updated: 10/9/20

	Purpose: To define the AVLTree class and declare it's member functions.

*/

#include "AVLNode.h"

template <class NODETYPE>
class AVLTree {

private:

	NODETYPE* root;
	string label;

public:

	//Default constructor
	AVLTree(){

		root = NULL;
		label = "";

	}


	//Destructor
	~AVLTree() {

		this->clear();
		label = "";

	}


	//Setters and Getters
	void set_root(NODETYPE* address) {
		root = address;
	}
	void set_label(string new_label) {
		label = new_label;
	}
	NODETYPE* get_root() {
		return root;
	}
	string get_label() {
		return label;
	}


	//Checks to see if the tree is empty
	int isEmpty() {

		if (root != NULL) {
			return 1;
		}
		else {
			return 0;

		}
	}


	//Returns height of the entered node
	int height(AVLNode<CancerData>* current) {

		return current->get_height();

	}


	//Insert function and its helper. Helper balances as it inserts
	void insert(CancerData new_data) {

		//Create new_node based on inputted data
		AVLNode<CancerData>* new_node = new AVLNode<CancerData>(1, nullptr, nullptr, new_data);

		//Insert the node through the tree if the tree isn't empty. Make the root the node if the tree is empty
		if (root == nullptr) {

			this->set_root(new_node);

		}
		else {

			this->set_root(insert_helper(new_node, root));
			
		}

	}
	AVLNode<CancerData>* insert_helper(AVLNode<CancerData>* target_node, AVLNode<CancerData>* current) {

		//Get data for comparison
		CancerData* current_data = nullptr;
		CancerData* target_data = new CancerData(&target_node->get_data());
		AVLNode<CancerData>* current_left = nullptr;
		AVLNode<CancerData>* current_right = nullptr;
		CancerData* current_left_data = nullptr;
		CancerData* current_right_data = nullptr;
		bool current_initialized = false;
		bool left_initialized = false;
		bool right_initialized = false;

		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new CancerData(&current->get_data());
			current_initialized = true;

			current_left = current->get_left();
			current_right = current->get_right();

			if (current_left != nullptr) {
				current_left_data = new CancerData(&current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new CancerData(&current_right->get_data());
				right_initialized = true;
			}

		}

		//If there isn't anything here, set the leaf to the target
		if (current_initialized == false) {
			return target_node;
		}

		//Initialize balance_factor
		int balance_factor = 0;

		//Do recursive insertion
		if (current_data->get_rate() > target_data->get_rate()) {

			current->set_left(insert_helper(target_node, current->get_left()));

		}
		else if(current_data->get_rate() <=  target_data->get_rate()){

			current->set_right(insert_helper(target_node, current->get_right()));

		}
		
		//Sets the height of the current node in the recursion
		current->set_height(1 + this->find_max_between_2_heights(current));

		//Get the balance factor to see if the subtree is balanced
		if (current->get_left() == NULL && current->get_right() == NULL) {
			balance_factor = 0;
		}
		else if (current->get_left() == NULL) {
			balance_factor = height(current->get_right()) * -1;
		}
		else if (current->get_right() == NULL) {
			balance_factor = height(current->get_left());
		}
		else {
			balance_factor = height(current->get_left()) - height(current->get_right());
		}
		//balance_factor = height(current->get_left()) - height(current->get_right());
		

		//Left Left
		//if (left_initialized) {
			if (balance_factor > 1 && target_data->get_rate() < current_left_data->get_rate()) {

				return rotate_right(current);

			}
		//}
		//if (right_initialized) {
			//Right Right
			if (balance_factor < -1 && target_data->get_rate() > current_right_data->get_rate()) {

				return rotate_left(current);

			}
		//}
		//if (left_initialized && right_initialized) {
			//Left Right
			if (balance_factor > 1 && target_data->get_rate() > current_left_data->get_rate())
			{
				current->set_left(rotate_left(current->get_left()));
				return rotate_right(current);
			}
			//Right Left
			if (balance_factor < -1 && target_data->get_rate() < current_right_data->get_rate())
			{
				current->set_right(rotate_right(current->get_right()));
				return rotate_left(current);

			}
		//}
		
		
	
		return current;

	}


	//Remove function and its helper. Balances as it recursively removes
	void remove(CancerData target) {

		if (root != nullptr) {

			this->set_root(remove_helper(root, target));

		}
		else {

			cout << endl << endl << "REMOVE FAIL: Nothing to remove" << endl << endl;

		}

	}
	AVLNode<CancerData>* remove_helper(AVLNode<CancerData>* current, CancerData target) {

		//Get data for comparison
		CancerData* current_data = nullptr;
		AVLNode<CancerData>* current_left = nullptr;
		AVLNode<CancerData>* current_right = nullptr;
		CancerData* current_left_data = nullptr;
		CancerData* current_right_data = nullptr;
		bool current_initialized = false;
		bool left_initialized = false;
		bool right_initialized = false;

		AVLNode<CancerData>* temp;

		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new CancerData(&current->get_data());
			current_initialized = true;

			current_left = current->get_left();
			current_right = current->get_right();

			if (current_left != nullptr) {
				current_left_data = new CancerData(&current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new CancerData(&current_right->get_data());
				right_initialized = true;
			}

		}

		//If there isn't anything here, set the leaf to the target
		if (current_initialized == false) {
			return current;
		}


		//Recursively look for node to delete. Deletes node if the data matches the target
		if (target.get_country() == current_data->get_country()) {

			//No leaves case
			if (!left_initialized && !right_initialized) {

				delete current;

			}
			//1 Leaf case
			else if (!right_initialized) {

				temp = new AVLNode<CancerData>(current->get_left());
				*current = *temp;
				delete temp;

			}
			else if (!left_initialized) {

				temp = new AVLNode<CancerData>(current->get_right());
				*current = *temp;
				delete temp;

			}
			//2 Leaves case			
			else {
				
				temp = new AVLNode<CancerData>(find_min_node_helper(current->get_right()));
				current->set_data(temp->get_data());
				current->set_right(remove_helper(current->get_right(), temp->get_data()));

			}

		}
		else if (target.get_rate() < current_data->get_rate()) {

			current->set_left(remove_helper(current->get_left(), target));

		}
		else if (target.get_rate() >= current_data->get_rate()) {

			current->set_right(remove_helper(current->get_right(), target));

		}

		//Check to see if the current was changed to null
		if (current == nullptr) {
			return current;
		}


		//Sets the height of the current node in the recursion after changes are made
		current->set_height(1 + this->find_max_between_2_heights(current));

		//Initialize balance_factor
		int balance_factor = 0;

		//Get the balance factor to see if the subtree is balanced after deletion
		if (current->get_left() == NULL && current->get_right() == NULL) {
			balance_factor = 0;
		}
		else if (current->get_left() == NULL) {
			balance_factor = height(current->get_right()) * -1;
		}
		else if (current->get_right() == NULL) {
			balance_factor = height(current->get_left());
		}
		else {
			balance_factor = height(current->get_left()) - height(current->get_right());
		}

		//Left Left
		if (balance_factor > 1 && height(current_left->get_left()) - height(current_left->get_right()) >= 0) {

			return rotate_right(current);

		}		
		//Left Right
		else if (balance_factor > 1 && height(current_left->get_left()) - height(current_left->get_right()) < 0){

			return rotate_right(current);

		}
		//Right Right
		else if (balance_factor < -1 && height(current_right->get_left()) - height(current_right->get_right()) <= 0) {

			return rotate_left(current);

		}
		//Right Left
		else if (balance_factor < -1 && height(current_right->get_left()) - height(current_right->get_right()) > 0)
		{

			return rotate_left(current);

		}


		return current;

	}


	//Deletes all members in the tree
	void clear() {

		if (this->root != NULL) {
			this->clear_helper(this->root);
		}

		this->root = NULL;
	}


	//Clears the entered subtree
	void clear_helper(AVLNode<CancerData>* target_root) {

		if (target_root != NULL) {

			clear_helper(target_root->get_left());
			clear_helper(target_root->get_right());
			delete target_root;

		}

	}


	//Finds max and min cancer rates in the tree with their helpers
	float findMax() {

		return this->find_max_helper(root);

	}
	float find_max_helper(AVLNode<CancerData>* root) {

		if (!root->get_right()) {
			CancerData* temp = new CancerData(&root->get_data());
			return temp->get_rate();
		}
		
		return find_max_helper(root->get_right());

	}
	float findMin() {

		return this->find_min_helper(root);

	}
	float find_min_helper(AVLNode<CancerData>* root) {

		if (!root->get_left()) {
			CancerData* temp = new CancerData(&root->get_data());
			return temp->get_rate();
		}

		return find_min_helper(root->get_left());

	}
	//Finds the nodes that contain the max and min values
	AVLNode<CancerData>* find_max_node() {

		return this->find_max_node_helper(root);

	}
	AVLNode<CancerData>* find_max_node_helper(AVLNode<CancerData>* root) {

		if (!root->get_right()) {
			return root;
		}

		return find_max_node_helper(root->get_right());

	}
	AVLNode<CancerData>* find_min_node() {

		return this->find_min_node_helper(root);

	}
	AVLNode<CancerData>* find_min_node_helper(AVLNode<CancerData>* root) {

		if (!root->get_left()) {
			return root;
		}

		return find_min_node_helper(root->get_left());

	}


	//Print in reverse order and its helper
	void printInOrder() {

		this->print_helper(this->root);

	}
	void print_helper(AVLNode<CancerData>* root) {

		if (!root) {
			return;
		}

		print_helper(root->get_left());

		CancerData* temp = new CancerData(&root->get_data());
		cout << "<" << label << ":" << temp->get_country() << "." << temp->get_rate() << ">" << endl;

		print_helper(root->get_right());

	}


	//finds max value between 2 heights of subtrees
	int find_max_between_2_heights(AVLNode<CancerData>* node) {

		if (node != nullptr) {

			AVLNode<CancerData>* left = node->get_left();
			AVLNode<CancerData>* right = node->get_right();

			if (left == nullptr && right == nullptr) {
				return 0;
			}
			else if (left == nullptr) {
				return right->get_height();
			}
			else if (right == nullptr) {
				return left->get_height();
			}
			else if (left->get_height() > right->get_height()) {
				return left->get_height();
			}
			else {
				return right->get_height();
			}

		}
		else {
			return 0;
		}
		

	}


	//Print in reverse order and its helper
	void print_in_order_reverse() {

		stack<AVLNode<CancerData>>* order_stack = new stack<AVLNode<CancerData>>();
		this->print_helper_reverse(this->root, order_stack);

		CancerData* print_data;
		AVLNode<CancerData>* temp;

		int size = order_stack->size();

		while (!order_stack->empty()) {

			temp = new AVLNode<CancerData>(&order_stack->top());
			print_data = new CancerData(&temp->get_data());

			/*cout << endl;
			cout << "Rank: " << order_queue->size() << endl;
			cout << "Country: " << print_data->get_country() << endl;
			cout << "Cancer Rate: " << print_data->get_rate() << endl;
			cout << "Height: " << temp->get_height() << endl;*/
			cout << "<" << label << ":" << size - order_stack->size() + 1 << "." << print_data->get_country() << "." << print_data->get_rate() << ">" << endl;

			order_stack->pop();
		}



	}
	void print_helper_reverse(AVLNode<CancerData>* root, stack<AVLNode<CancerData>>* destination) {

		if (!root) {
			return;
		}

		print_helper_reverse(root->get_left(), destination);

		destination->push(*root);

		print_helper_reverse(root->get_right(), destination);

	}


	//Rotation functions
	AVLNode<CancerData>* rotate_left(AVLNode<CancerData>* current) {

		//Create nodes to hold nodes as they rotate
		AVLNode<CancerData>* temp1 = current->get_right();
		AVLNode<CancerData>* temp2 = temp1->get_left();

		//Rotate left
		/*
			c			1
			 \		   /
			  1 ----> c
			 /		   \
			2		    2
		*/
		temp1->set_left(current);
		current->set_right(temp2);


		//Make heights accurate after rotation  
		current->set_height(find_max_between_2_heights(current) + 1);
		temp1->set_height(find_max_between_2_heights(temp1) + 1);
		//temp2 height remains unchanged

		return temp1;

	}
	AVLNode<CancerData>* rotate_right(AVLNode<CancerData>* current) {

		//Create nodes to hold nodes as they rotate
		AVLNode<CancerData>* temp1 = current->get_left();
		AVLNode<CancerData>* temp2 = temp1->get_right();

		//Rotate right
		/*
			c			1
		   /			 \
		  1     ---->     c
		   \		     /
			2		    2

		*/
		temp1->set_right(current);
		current->set_left(temp2);

		//Make heights accurate after rotation  
		current->set_height(find_max_between_2_heights(current) + 1);
		temp1->set_height(find_max_between_2_heights(temp1) + 1);
		//temp2 height remains unchanged

		return temp1;

	}
	
};