#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/30/20

	Purpose: To define the RedBlackNode class and define it's member functions.

*/

#include "InventoryRecord.h"

template <class DATATYPE>
class RedBlackNode {

private:

	//template datatype
	DATATYPE Data;
	// 'r' = red, 'b' = black. Anything else is an error
	char color;

	//only applies if node is black (REMOVED. NO CURRENT PURPOSE)
	int b_height;

	//Relevant pointers
	RedBlackNode<DATATYPE>* parent;
	RedBlackNode<DATATYPE>* left;
	RedBlackNode<DATATYPE>* right;

public:

	//Default Constructor
	RedBlackNode() {

		Data = NULL;
		color = 'r';
		b_height = 0;
		parent = NULL;
		left = NULL;
		right = NULL;

	}

	//Destructor
	~RedBlackNode() {

		//delete caused errors since it basically deallocates everything underneath this node so I set the variables to null instead.
		left = nullptr;
		right = nullptr;
		parent = nullptr;

	}

	//Copy constructor
	RedBlackNode(RedBlackNode<DATATYPE>* new_parent, RedBlackNode<DATATYPE>* new_left, RedBlackNode<DATATYPE>* new_right, DATATYPE new_data, char new_color, int new_b_height) {

		Data = new_data;
		color = new_color;
		b_height = new_b_height;
		parent = new_parent;
		left = new_left;
		right = new_right;

	}

	//Copy constructor from existing object
	explicit RedBlackNode(RedBlackNode<DATATYPE>* new_data) {

		this->set_data(new_data->get_data());
		this->set_color(new_data->get_color());
		this->set_left(new_data->get_left());
		this->set_right(new_data->get_right());
		this->set_parent(new_data->get_parent());

	}

	//Setters and Getters
	void set_data(DATATYPE new_data) {
		Data = new_data;
	}
	void set_color(char new_color) {
		color = new_color;
	}
	void set_b_height(int new_b_height) {
		b_height = new_b_height;
	}
	void set_left(RedBlackNode<DATATYPE>* new_left) {
		left = new_left;
	}
	void set_right(RedBlackNode<DATATYPE>* new_right) {
		right = new_right;
	}
	void set_parent(RedBlackNode<DATATYPE>* new_parent) {
		parent = new_parent;
	}
	DATATYPE get_data() {
		return Data;
	}
	char get_color() {
		return color;
	}
	int get_b_height() {
		return b_height;
	}
	RedBlackNode<DATATYPE>* get_left() {
		return left;
	}
	RedBlackNode<DATATYPE>* get_right() {
		return right;
	}
	RedBlackNode<DATATYPE>* get_parent() {
		return parent;
	}

};