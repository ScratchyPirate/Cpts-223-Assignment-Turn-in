
/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/31/20

	Purpose: To define the InventoryRecord member functions.

*/

#include "declarations.h"

int menu() {

	int option = 0; 

	cout << "EXPLORERS OF CRYDON" << endl;
	cout << "1: Rules" << endl;
	cout << "2: Check Ship Invventory" << endl;
	cout << "3: Add to your inventory (You can have this item on your ship, but it will not update like the other items)" << endl;
	cout << "4: Update existing inventory item" << endl;
	cout << "5: Remove an item (WARNING. REMOVING A BASE GAME ITEM WILL END THE GAME) (Also it doesn't work perfectly if you don't delete in order from least to greatest. I couldn't figure out a solution to this)" << endl;
	cout << "6: Play game" << endl;
	cout << "7: Exit" << endl;

	cin >> option;
	system("cls");

	return option;
}