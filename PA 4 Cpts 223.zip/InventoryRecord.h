#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/30/20

	Purpose: To define the InventoryRecord class, define its constructor, destructor, copy constructors, copy assignment, and declare it's other member functions.

*/

#include "declarations.h"

class InventoryRecord {


private:
	
	int ID;
	string type;
	int num_items;

public:

	//Default Constructor
	InventoryRecord() {

		ID = 0;
		type = "";
		num_items = 0;

	}

	//Explicit constructor
	explicit InventoryRecord(int new_ID, string new_type, int new_num) {

		ID = new_ID;
		type = new_type;
		num_items = new_num;

	}

	//Copy Constructor
	explicit InventoryRecord(InventoryRecord* new_data) {

		this->set_ID(new_data->get_ID());
		this->set_type(new_data->get_type());
		this->set_num_items(new_data->get_num_items());

	}

	//Destructor. (Without addresses to delete I'm not sure what to delete. You can't delete the addresses of the
	// variables. "delete[] &country" doesn't work so I'm leaving this blank unless I come back to it and add
	// other members with addresses)
	~InventoryRecord() {


	}

	//Copy Assignment
	InventoryRecord& operator=(InventoryRecord& source) {

		this->ID = source.ID;
		this->type = source.type;
		this->num_items = source.num_items;

		return *this;

	}

	//Setters and Getters
	void set_ID(int new_ID);
	void set_type(string new_type);
	void set_num_items(int new_num);
	int get_ID();
	string get_type();
	int get_num_items();

};