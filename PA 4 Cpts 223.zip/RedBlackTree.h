#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/31/20

	Purpose: To define the RedBlackTree class and define it's member functions.

*/

#include "RedBlackNode.h"

class RedBlackTree {

private:

	RedBlackNode<InventoryRecord>* root;

public:


	//Default Constructor
	RedBlackTree() {

		root = nullptr;

	}


	//Destructor
	~RedBlackTree() {

		this->clear();

	}


	//Setter and Getter functions
	void set_root(RedBlackNode<InventoryRecord>* new_root) {
		root = new_root;
	}
	RedBlackNode<InventoryRecord>* get_root() {
		return root;
	}


	//Checks if the tree is empty
	int isEmpty() {

		if (root != NULL) {
			return 1;
		}
		else {
			return 0;
		}

	}


	//Insert function and its insert helper
	void insert(InventoryRecord new_data) {

		//Create new_node based on inputted data
		RedBlackNode<InventoryRecord>* new_node = new RedBlackNode<InventoryRecord>(NULL,NULL,NULL,new_data,'r',0);

		//Insert the node through the tree if the tree isn't empty. Make the root the node if the tree is empty
		if (root == nullptr) {

			new_node->set_color('b');
			this->set_root(new_node);

		}
		else {

			//new_node->set_b_height(1);
			this->set_root(insert_helper(root, new_node));

			this->rotate_and_recolor(new_node);
		}

	}
	RedBlackNode<InventoryRecord>* insert_helper(RedBlackNode<InventoryRecord>* current, RedBlackNode<InventoryRecord>* new_node) {

		//Get data for comparison
		InventoryRecord* current_data = nullptr;
		InventoryRecord* new_node_data = new InventoryRecord(&new_node->get_data());
		RedBlackNode<InventoryRecord>* current_left = nullptr;
		RedBlackNode<InventoryRecord>* current_right = nullptr;
		RedBlackNode<InventoryRecord>* current_parent = nullptr;
		RedBlackNode<InventoryRecord>* current_grandparent = nullptr;
		RedBlackNode<InventoryRecord>* current_uncle = nullptr;
		InventoryRecord* current_left_data = nullptr;
		InventoryRecord* current_right_data = nullptr;
		InventoryRecord* current_parent_data = nullptr;
		InventoryRecord* current_grandparent_data = nullptr;
		InventoryRecord* current_uncle_data = nullptr;
		bool left_initialized = false;
		bool right_initialized = false;
		bool parent_initialized = false;
		bool grandparent_initialized = false;
		bool uncle_initialized = false;
		bool uncle_left = false;
		bool uncle_right = false;

		char temp_char = '\0';

		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new InventoryRecord(&current->get_data());

			current_left = current->get_left();
			current_right = current->get_right();
			current_parent = current->get_parent();

			if (current_left != nullptr) {
				current_left_data = new InventoryRecord(&current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new InventoryRecord(&current_right->get_data());
				right_initialized = true;
			}
			if (current_parent != nullptr) {
				current_parent_data = new InventoryRecord(&current_parent->get_data());
				parent_initialized = true;
			}

		}
		else {
			//If there isn't anything here, set the leaf to the target
			return new_node;
		}

		////Get data from the grandparent and uncle if they exist for later rotations and color changes if needed
		//if (parent_initialized == true) {

		//	current_grandparent = current_parent->get_parent();

		//	if (current_grandparent != nullptr) {
		//		current_grandparent_data = new InventoryRecord(&current_grandparent->get_data());
		//		grandparent_initialized = true;
		//	}

		//}
		//if (grandparent_initialized == true) {

		//	if (current_parent == current_grandparent->get_left()) {
		//		current_uncle = current_grandparent->get_right();
		//		uncle_right = true;
		//	}
		//	else {
		//		current_uncle = current_grandparent->get_left();
		//		uncle_left = true;
		//	}

		//	if (current_uncle != nullptr) {
		//		current_uncle_data = new InventoryRecord(&current_uncle->get_data());
		//		uncle_initialized = true;
		//	}
		//}

		//Do recursive insertion
		if (current_data->get_ID() > new_node_data->get_ID()) {

			current->set_left(insert_helper(current->get_left(), new_node));
			new_node->set_parent(current);

		}
		else if (current_data->get_ID() < new_node_data->get_ID()) {

			current->set_right(insert_helper(current->get_right(), new_node));
			new_node->set_parent(current);

		}
		else {

			//Update existing node with new data
			current = new_node;

		}
		
		return current;

	}
	
	//Remove function and its delete helper
	//Insert the node through the tree if the tree isn't empty. Make the root the node if the tree is empty
	void remove(int target_ID) {
		if (root != nullptr) {

			RedBlackNode<InventoryRecord>* new_root = remove_helper(root, target_ID);
			this->set_root(new_root);
			this->rotate_and_recolor(new_root);

		}
		else {

			cout << "ERROR: Nothing to remove" << endl;

		}
	}
	RedBlackNode<InventoryRecord>* remove_helper(RedBlackNode<InventoryRecord>* current, int target_ID) {

		//Get data for comparison
		InventoryRecord* current_data = nullptr;
		RedBlackNode<InventoryRecord>* temp = nullptr;
		InventoryRecord* temp_data = nullptr;
		RedBlackNode<InventoryRecord>* current_left = nullptr;
		RedBlackNode<InventoryRecord>* current_right = nullptr;
		RedBlackNode<InventoryRecord>* current_parent = nullptr;
		RedBlackNode<InventoryRecord>* current_grandparent = nullptr;
		RedBlackNode<InventoryRecord>* current_uncle = nullptr;
		InventoryRecord* current_left_data = nullptr;
		InventoryRecord* current_right_data = nullptr;
		InventoryRecord* current_parent_data = nullptr;
		InventoryRecord* current_grandparent_data = nullptr;
		InventoryRecord* current_uncle_data = nullptr;
		bool left_initialized = false;
		bool right_initialized = false;
		bool parent_initialized = false;
		bool grandparent_initialized = false;
		bool uncle_initialized = false;
		bool uncle_left = false;
		bool uncle_right = false;


		//Makes sure there's no access violations
		if (current != nullptr) {

			current_data = new InventoryRecord(&current->get_data());

			current_left = current->get_left();
			current_right = current->get_right();
			current_parent = current->get_parent();

			if (current_left != nullptr) {
				current_left_data = new InventoryRecord(&current_left->get_data());
				left_initialized = true;
			}
			if (current_right != nullptr) {
				current_right_data = new InventoryRecord(&current_right->get_data());
				right_initialized = true;
			}
			if (current_parent != nullptr) {
				current_parent_data = new InventoryRecord(&current_parent->get_data());
				parent_initialized = true;
			}

		}

		//If the function finds that the current its trying to delete is at a null leaf, fail to remove
		//If the Id is less than the current, move down left
		//If the Id is greater than the current, move down right
		//If equal, found target node to delete. Breaks down into cases below
		if (current == nullptr) {
			cout << "Failed to find" << endl;
			return current;
		}
		else if (current_data->get_ID() > target_ID) {

			current->set_left(remove_helper(current_left, target_ID));

		}
		else if (current_data->get_ID() < target_ID) {

			current->set_right(remove_helper(current_left, target_ID));

		}
		else{

			//No leaves case
			if (!left_initialized && !right_initialized) {

				delete current;
				current = nullptr;

			}
			//1 Leaf case
			else if (!right_initialized) {

				temp = new RedBlackNode<InventoryRecord>(current->get_left());
				*current = *temp;
				delete temp;

			}
			else if (!left_initialized) {

				temp = new RedBlackNode<InventoryRecord>(current->get_right());
				*current = *temp;
				delete temp;

			}
			//2 Leaves case			
			else {

				temp = new RedBlackNode<InventoryRecord>(find_min_node_helper(current->get_right()));
				temp_data = new InventoryRecord(temp->get_data());
				current->set_data(*temp_data);
				current->set_right(remove_helper(current->get_right(), temp_data->get_ID()));

			}

		}

		return current;

	}
	
	//Deletes all members in the tree
	void clear() {

		if (this->root != NULL) {
			this->clear_helper(this->root);
		}

		this->root = NULL;
	}
	//Clears the entered tree or subtree
	void clear_helper(RedBlackNode<InventoryRecord>* target_root) {

		if (target_root != NULL) {

			clear_helper(target_root->get_left());
			clear_helper(target_root->get_right());
			delete target_root;

		}

	}


	//Print in order and its helper
	void printInOrder() {

		cout << "Current Inventory: " << endl << endl;

		this->print_helper(this->root);

		cout << endl << "Press any button to continue " << endl << endl;
		_getch();

		system("CLS");

	}
	void print_helper(RedBlackNode<InventoryRecord>* root) {

		if (root == nullptr) {
			return;
		}

		print_helper(root->get_left());

		InventoryRecord* temp = new InventoryRecord(&root->get_data());
		string temp_s;

		cout << temp->get_ID() << ": " << temp->get_type();
		temp_s = temp->get_type();

		for (int i = temp_s.size(); i < 15; i++) {
			cout << " ";
		}
		cout << "| " << temp->get_num_items() << endl;

		print_helper(root->get_right());

	}


	//Rotation functions
	void rotate_left(RedBlackNode<InventoryRecord>* current) {

		//Create nodes to hold nodes as they rotate
		RedBlackNode<InventoryRecord>* temp1 = current->get_right();
		RedBlackNode<InventoryRecord>* temp2 = temp1->get_left();
		RedBlackNode<InventoryRecord>* temp3 = current->get_parent();;

		//Rotate left. Adjusts parents as well.
		if (temp2 != nullptr) {
			temp2->set_parent(current);
		}

		temp1->set_parent(temp3);

		if (temp3 == nullptr) {
			root = temp1;
		}
	
		else if (current == temp3->get_left()) {
			temp3->set_left(temp1);
		}
		else {
			temp3->set_right(temp1);
		}

		temp1->set_left(current);
		current->set_parent(temp1);


	}
	void rotate_right(RedBlackNode<InventoryRecord>* current) {

		//Create nodes to hold nodes as they rotate
		RedBlackNode<InventoryRecord>* temp1 = current->get_left();
		RedBlackNode<InventoryRecord>* temp2 = temp1->get_right();
		RedBlackNode<InventoryRecord>* temp3 = current->get_parent();;

		//Rotate right. Adjusts parents as well.
		if (temp2 != nullptr) {
			temp2->set_parent(current);
		}

		temp1->set_parent(temp3);

		if (temp3 == nullptr) {
			root = temp1;
		}
		else if (current == temp3->get_left()) {
			temp3->set_left(temp1);
		}
		else {
			temp3->set_right(temp1);
		}

		temp1->set_right(current);
		current->set_parent(temp1);

	}


	//Universal balancer after insertion or deletion
	void rotate_and_recolor(RedBlackNode<InventoryRecord>* new_node) {

		//Get data for comparison
		RedBlackNode<InventoryRecord>* current_left = nullptr;
		RedBlackNode<InventoryRecord>* current_right = nullptr;
		RedBlackNode<InventoryRecord>* current_parent = nullptr;
		RedBlackNode<InventoryRecord>* current_grandparent = nullptr;
		RedBlackNode<InventoryRecord>* current_uncle = nullptr;
		bool left_initialized = false;
		bool right_initialized = false;
		bool parent_initialized = false;
		bool grandparent_initialized = false;
		bool uncle_initialized = false;
		//o = uninitialized, 1 = left, 2 = right.
		int uncle = 0;

		char temp_char = '\0';

		//Makes sure there's no access violations
		if (new_node != nullptr) {

			current_left = new_node->get_left();
			current_right = new_node->get_right();
			current_parent = new_node->get_parent();

			if (current_left != nullptr) {
				left_initialized = true;
			}
			if (current_right != nullptr) {
				right_initialized = true;
			}
			if (current_parent != nullptr) {
				parent_initialized = true;
			}

		}

		//Get data from the grandparent and uncle if they exist for later rotations and color changes if needed
		if (parent_initialized == true) {

			current_grandparent = current_parent->get_parent();

			if (current_grandparent != nullptr) {
				grandparent_initialized = true;
			}

		}
		if (grandparent_initialized == true) {

			if (current_parent == current_grandparent->get_left()) {
				current_uncle = current_grandparent->get_right();
				uncle = 2;
			}
			else {
				current_uncle = current_grandparent->get_left();
				uncle = 1;
			}

			if (current_uncle != nullptr) {
				uncle_initialized = true;
			}
		}

		//Continue to update while the coloring properties and balancing properties of the RB tree are imbalanced
		while (((new_node != root) && new_node->get_color() != 'b') && current_parent->get_color() == 'r') {

			//If current is left of grandparent
			if (uncle == 2) {

				//Recolor if uncle is red. No rotations
				if (uncle_initialized && current_uncle->get_color() == 'r') {
					current_grandparent->set_color('r');
					current_parent->set_color('b');
					current_uncle->set_color('b');
					new_node = current_grandparent;
				}

				else {

					//Rotate left if the current is right of its parent
					if (new_node == current_parent->get_right()) {
						rotate_left(current_parent);
						new_node = current_parent;
						current_parent = new_node->get_parent();
					}
					//Rotate right and swap colors of parent and grandparent. Update new_node
					rotate_right(current_grandparent);
					temp_char = current_grandparent->get_color();
					current_grandparent->set_color(current_parent->get_color());
					current_parent->set_color(temp_char);
					new_node = current_parent;


				}

			}
			//If current is right of grandparent (uncle_left_initialized)
			else {

				//Recolor if uncle is red. No rotations
				if (uncle_initialized && current_uncle->get_color() == 'r') {
					current_grandparent->set_color('r');
					current_parent->set_color('b');
					current_uncle->set_color('b');
					new_node = current_grandparent;
				}

				else {

					//Rotate right if current is left of parent
					if (new_node == current_parent->get_left()) {
						rotate_right(current_parent);
						new_node = current_parent;
						current_parent = new_node->get_parent();
					}
					//Rotate left and swap colors of parent and grandparent. Update new_node
					rotate_left(current_grandparent);
					temp_char = current_grandparent->get_color();
					current_grandparent->set_color(current_parent->get_color());
					current_parent->set_color(temp_char);
					new_node = current_parent;
				}

			}

		}

		if (new_node == root && new_node != nullptr) {
			root->set_parent(nullptr);
		}
		if (root != nullptr) {
			root->set_color('b');
		}

	}

	//Function from my PA 3 that finds the minimum value in a subtree.
	RedBlackNode<InventoryRecord>* find_min_node_helper(RedBlackNode<InventoryRecord>* root) {

		if (!root->get_left()) {
			return root;
		}

		return find_min_node_helper(root->get_left());

	}

	//A function that updates an inputed ID
	void update(RedBlackNode<InventoryRecord>* current, int target_ID) {


		string temp_s;
		int temp_num;

		if (current == nullptr) {

			cout << "Failed to find" << endl;
			return; 

		}
		else {

			InventoryRecord* current_data = new InventoryRecord(current->get_data());

			if (current_data->get_ID() > target_ID) {

				update(current->get_left(), target_ID);

			}
			else if (current_data->get_ID() < target_ID) {

				update(current->get_right(), target_ID);

			}
			else {

				//Verify the ID was found
				cout << "ID found: " << target_ID << endl;
				cout << "<" << current_data->get_ID() << ":" << current_data->get_type() << ":" << current_data->get_num_items() << ">" << endl;

				//Change type
				cout << "Enter the type you would like to change this to: ";
				cin >> temp_s;
				current_data->set_type(temp_s);

				//Change num_items
				cout << "Enter the num_items you would like to change this to: ";
				cin >> temp_num;
				current_data->set_num_items(temp_num);

				//Verify and set
				cout << "Changing data in ID: " << target_ID << endl;
				cout << "<" << current_data->get_ID() << ":" << current_data->get_type() << ":" << current_data->get_num_items() << ">" << endl;
				current->set_data(*current_data);

				return;

			}


		}



	}
};
