#pragma once

/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/31/20

	Purpose: To include libraries and define functions for all source code files in PA 4.

*/

#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <iostream>
#include <cstring>	
#include <vector>
#include <queue>
#include <initializer_list>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <Windows.h>
#include <conio.h>


int menu();