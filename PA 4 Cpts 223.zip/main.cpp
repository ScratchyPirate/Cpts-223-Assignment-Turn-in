

/*

	***************************************************************************************************************
	IMPORTANT NOTE: I found that I could reuse a lot of stuff from PA 3 which is why it may look similar to my PA 3
	***************************************************************************************************************
	
	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/31/20

	Purpose: To include necessary tasks for fufilling the requirements of PA 4.
	main.cpp does the following:
	-Read inverntory data from a .csv file, the data being in the format ID,Name,Quantity
	-Store said data into an RB tree
	-Display data

	I've also added the following features
	-A menu that can perform different actions on the tree such as
	+Update data
	+Delete items
	+Insert new inventory
	+Store the inventory back into the .csv file when done
	+Simulate days that go by and update data accordingly
	+Different events can occur as well during these days

	***************************************************************************************************************
	IMPORTANT NOTE: I found that I could reuse a lot of stuff from PA 3 which is why it may look similar to my PA 3
	***************************************************************************************************************
	OTHER IMPORTANT NOTE: This game was never completed so I just turned in the basic PA 4 requirements. May
	continue in the future.
	***************************************************************************************************************
	
*/
/*
* PA 4 Questions:

What is the worst-case Big-O of the insert () algorithm for the red-black tree? Explain.
	Insert is O(logN) roughly. The balancing isn't as strict as it is with an AVL tree, but the height of the tree is still
	roughly logN where n is the number of nodes in the tree. This means that to get to each place to insert, you need to
	look down logN nodes before inserting. The rotations and recoloring can also take up logN time since they can effect some
	multiple of logN nodes so the overall algorithm is O(logN)

What is the worst-case Big-O of the remove () algorithm for the red-black tree? Explain.
	Remove is O(logN) roughly. For very much the same reason as the insert algorithm. At most, the remove function goes down 
	logN nodes and removes a node with no leaves and then rebalances after. The algorithm can also remove somewhere in the
	middle, but the nodes that the recoloring and rotations effect is preset based on the properties of the current tree. 
	So remove at worst case is O(logN).

What is the worst-case Big-O of the clear () algorithm for the red-black tree? Explain.
	Clear is easily O(n). The algorithm goes to each node and frees up memory for other uses. The algorithm frees memory
	N times, so the worst case for clear() is O(n).


*/

#include "RedBlackTree.h"

int main() {

	//Declare the red black tree
	RedBlackTree* Ship_Inventory = new RedBlackTree();

	//Declare and open inventory file for reading
	fstream inventory_file;
	inventory_file.open("Inventory.csv", ios::in);


	//Declare general variables
	string::size_type sz;
	RedBlackNode<InventoryRecord>* temp_node;
	InventoryRecord temp_data;
	string temp_s_1;
	string temp_s_2;
	string temp_s_3;
	bool playing = true;
	int option = 0;

	//Insertions from the file
	while (inventory_file.good()) {

		getline(inventory_file, temp_s_1, ',');
		getline(inventory_file, temp_s_2, ',');
		getline(inventory_file, temp_s_3, '\n');
		temp_data.set_ID(stoi(temp_s_1, &sz));
		temp_data.set_type(temp_s_2);
		temp_data.set_num_items(stoi(temp_s_3, &sz));

		cout << "Type loaded..." << endl;
		cout << temp_s_1 << ": " << temp_s_2 << ":" << temp_s_3 << endl;

		Ship_Inventory->insert(temp_data);

	}
	cout << endl << endl;

	system("cls");

	//Ship_Inventory->printInOrder();

	//Debug remove function. Uncomment to remove all items from the subtree one at a time
	/*for (int i = 1000; i < 1011; i++) {
		
		cout << "removing ID :" << i << endl;
		Ship_Inventory->remove(i);

		Ship_Inventory->printInOrder();

	}*/

	//_getch();


	//Plays game
	while (playing) {

		//Reset option before each option
		option = 0;

		//Menu
		do {

			option = menu();
			
		} while (option < 1 || option > 7);

		//Does different tasks based on the option
		switch (option) {


		//Rules
		case 1:

			cout << "TO-DO. Implement rules" << endl;
			cout << "Concept: you are the captain of a space ship and have crashed down on" << endl;
			cout << "an unknown planet you and your team were going to explore called Crydon." << endl;
			cout << "you have sent out a distress signal, but it will take 1 month for a" << endl;
			cout << "squadron to reach your location. You must survive with what resources" << endl;
			cout << "you have and keep your communication device up and running for 1 month" << endl;
			cout << "straight." << endl;
			break;


		//Display current inventory
		case 2:

			Ship_Inventory->printInOrder();
			break;


		//Insert
		case 3:
			
			//Gather 3 parts of InventoryRecord
			do {
				cout << "Enter the 4 digit ID of this new item" << endl;
				cin >> option;
				system("cls");
			} while (option < 1000 || option > 9999);
			temp_data.set_ID(option);

			cout << "Enter the type of item the new item is" << endl;
			cin >> temp_s_1;
			temp_data.set_type(temp_s_1);
			system("cls");

			cout << "Enter the number of items that you have" << endl;
			cin >> option;
			temp_data.set_num_items(option);
			system("cls");

			//Insert new data
			Ship_Inventory->insert(temp_data);

			//Verify Insertion
			Ship_Inventory->printInOrder();

			break;


		//Update
		case 4:
			
			//Display current tree data
			cout << "Here is the current inventory your ship has" << endl << endl;
			Ship_Inventory->printInOrder();

			//Gather ID and the data they want to update the ID with
			cout << "Which ID would you like to update? (Entering an ID that doesn't exist will insert a new item into the system)" << endl;
			do {
				cout << "Enter the 4 digit ID of the item" << endl;
				cin >> option;
				system("cls");
			} while (option < 1000 || option > 9999);

			//Update inputted ID
			Ship_Inventory->update(Ship_Inventory->get_root(), option);

			//Verify Update
			Ship_Inventory->printInOrder();

			break;


		//Delete
		case 5:

			//Display current tree data
			cout << "Here is the current inventory your ship has" << endl << endl;
			Ship_Inventory->printInOrder();

			//Gather ID and the data they want to update the ID with
			cout << "Which ID would you like to update? (Entering an ID that doesn't exist will insert a new item into the system)" << endl;
			do {
				cout << "Enter the 4 digit ID of the item" << endl;
				cin >> option;
				system("cls");
			} while (option < 1000 || option > 9999);

			//Delete inputted ID
			Ship_Inventory->remove(option);

			//Verify Deletion
			Ship_Inventory->printInOrder();

			break;

		//Play game
		case 6:
			cout << "TO-DO. Implement game" << endl;
			break;

		//Exit
		case 7:

			playing = false;
			Ship_Inventory->clear();
			break;

		//Catch case
		default:

			cout << "ERROR ENCOUNTERED: CASES NOT REACHED" << endl;
			break;

		}



	}

	//Close file before exitting program
	inventory_file.close();


	return 0;

}