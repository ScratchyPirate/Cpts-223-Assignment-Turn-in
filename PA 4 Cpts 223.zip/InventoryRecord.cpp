
/*

	File Creator: John Sbur
	Assignment: PA 4
	Class: Cpts 223
	Created: 10/26/20
	Last Updated: 10/30/20

	Purpose: To define the InventoryRecord member functions.

*/

#include "InventoryRecord.h"

void InventoryRecord::set_ID(int new_ID) {
	ID = new_ID;
}
void InventoryRecord::set_type(string new_type) {
	type = new_type;
}
void InventoryRecord::set_num_items(int new_num) {
	num_items = new_num;
}
int InventoryRecord::get_ID() {
	return ID;
}
string InventoryRecord::get_type() {
	return type;
}
int InventoryRecord::get_num_items() {
	return num_items;
}